const dayjs = require("dayjs");
let day = dayjs().format('MM-DD-YYYY');

describe("Routes: Index", () => {
    describe("GET /", () => {
        it("returns the API staus", done => {
            request.get("/")
                .expect(200)
                .end((err,res) => {
                    const expected = {
                    welcome: "Welcome to your APIFitness Meal Tracker Homepage! Head to /meals to view your Meals!",
                    date: day
                };
                    expect(res.body).to.eql(expected);
                    done(err);
                });
        });
    });
});