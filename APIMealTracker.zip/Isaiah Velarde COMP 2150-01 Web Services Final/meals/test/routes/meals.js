const jwt = require("jwt-simple");

describe("Routes: Meals", () => {
    const Users = app.db.models.Users;
    const Meals = app.db.models.Meals;
    const jwtSecret = app.libs.config.jwtSecret;
    let token;
    let fakeMeal;

    beforeEach(done => {
        Users
            .destroy({where: {}})
            .then(() => Users.create({
                name: "test",
                email: "test@test.com",
                password: "password"
            }))
            .then(user => {
                Meals
                    .destroy({where: {}})
                    .then(() => Meals.bulkCreate([{
                        id: 1,
                        mealType: "Breakfast",
                        food: "Eggs",
                        protein: 1,
                        carbs: 1,
                        sugars: 1,
                        cals: 1,
                        date: "2024-04-23",
                        UserId: user.id
                    }, {
                        id: 2,
                        mealType: "Lunch",
                        food: "Sandwich",
                        protein: 2,
                        carbs: 2,
                        sugars: 2,
                        cals: 2,
                        date: "2024-04-23",
                        UserId: user.id  
                    },{
                        id: 3,
                        mealType: "Dinner",
                        food: "Chicken & Rice",
                        protein: 3,
                        carbs: 3,
                        sugars: 3,
                        cals: 3,
                        date: "2024-04-23",
                        UserId: user.id  
                    }]))
                    .then(meals => {
                        fakeMeal = meals[0];
                        token = jwt.encode({id: user.id}, jwtSecret);
                        userID = user.id;
                        done();
                    });
            });
    });
    describe("GET /meals", () => {
        describe("Status 200", () => {
            it("Returns a list of my meals", done => {
                request.get("/meals")
                    .set("Authorization", "JWT " + token)
                    .expect(200)
                    .end((err, res) => {
                        expect(res.body).to.have.length(3);
                        expect(res.body[0].mealType).to.eql("Breakfast");
                        expect(res.body[1].protein).to.eql(2);
                        expect(res.body[2].food).to.eql("Chicken & Rice");
                        done(err);
                    });
            });
        });
    });
    describe("POST /meals", () => {
        describe("Status 200", () => {
            it("Creates a new meal", done => {
                request.post("/meals")
                    .set("Authorization", "JWT " + token)
                    .send({
                        mealType: "Snack",
                        food: "Cookies",
                        protein: 4,
                        carbs: 4,
                        sugars: 4,
                        cals: 4,
                        date: "2024-04-23"
                    })
                    .expect(200)
                    .end((err, res) => {
                        expect(res.body.food).to.eql("Cookies");
                        done(err);
                    })
            });
        });
    });
    describe("GET /meals/:id", () => {
        describe("Status 200", () => {
            it("Returns a meal based off of ID", done => {
                request.get("/meals/" + fakeMeal.id)
                .set("Authorization", "JWT " + token)
                .expect(200)
                .end((err, res) => {
                    expect(res.body.carbs).to.eql(1);
                    done(err);
                })
            });
        });
        describe("Status 404", () => {
            it("Throws error that meal does not exist", done => {
                request.get("/meals/0")
                    .set("Authorization", "JWT " + token)
                    .expect(404)
                    .end((err, res) => done(err));
            });
        });
    });
    describe("PUT /meals/:id", () => {
        describe("Status 204", () => {
            it("Updates a meal", done => {
                request.put("/meals/" + fakeMeal.id)
                .set("Authorization", "JWT " + token)
                .send({
                    food: "Eggs & Bacon",
                    done: true
                })
                .expect(204)
                .end((err, res) => done(err));
            });
        });
    });
    describe("DELETE /meals/:id", () => {
        describe("Status 204", () => {
            it("Removes a reading", done => {
                request.delete("/meals/" + fakeMeal.id)
                .set("Authorization", "JWT " + token)
                .expect(204)
                .end((err, res) => done(err));
            });
        });
    });
});