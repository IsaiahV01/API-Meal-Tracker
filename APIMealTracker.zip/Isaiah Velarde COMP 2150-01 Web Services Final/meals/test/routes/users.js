const jwt = require("jwt-simple");

describe("Routes: Users", () => {
    const Users = app.db.models.Users;
    const jwtSecret = app.libs.config.jwtSecret;
    let token;
    beforeEach(done => {
        Users
            .destroy({where: {}})
            .then(() => Users.create({
                name: "test",
                password: "password",
                email: "test@test.com"
            }))
            .then(user => {
                token = jwt.encode({id: user.id}, jwtSecret);
                done();
            });
    });
    describe("GET /user", () => {
        describe("Status 200", () => {
            it("Returns an authenticated user", done => {
                request.get("/user")
                .set("Authorization", "JWT " + token)
                .expect(200)
                .end((err, res) => {
                    //console.log(res.body);
                    expect(res.body.name).to.eql("test");
                    expect(res.body.email).to.eql("test@test.com");
                    done(err);
                });
            });
        });
    });
    describe("DELETE /user", () => {
        describe("Status 204", () => {
            it("Deletes an authenticated user", done => {
                request.delete("/user")
                    .set("Authorization", "JWT " + token)
                    .expect(204)
                    .end((err, res) => done(err));
            });
        });
    });
    describe("POST /users", () => {
        describe("Status 200", () => {
            it("Creates a new user", done => {
                request.post("/users")
                    .send ({
                        name: "one test man",
                        email: "otm@test.com",
                        password: "ONETEST"
                    })
                    .expect(200)
                    .end((err, res) => {
                        expect(res.body.name).to.eql("one test man");
                        expect(res.body.email).to.eql("otm@test.com");
                        done(err);
                    })
            });
        });
    });
});