module.exports = app => {
    const dayjs = require("dayjs");
    let day = dayjs().format('MM-DD-YYYY'); 
    /**
     * @api {get} / API Index
     * @apiGroup Welcome Index
     * @apiSuccess {String} welcome API Welcome message
     * @apiSuccessExample {json} Success
     *  HTTP/1.1 200 OK
     *  {
     *      welcome: "Welcome to your APIFitness Meal Tracker Homepage! Head to /meals to view you Meals!",
     *      date: day
     *  }
     */
    app.get("/", (req, res) => {res.json(
        {
            welcome: "Welcome to your APIFitness Meal Tracker Homepage! Head to /meals to view your Meals!",
            date: day
        })});
};