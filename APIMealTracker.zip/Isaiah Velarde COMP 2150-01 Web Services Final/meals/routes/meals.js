module.exports = app => {
    const mealsData = app.db.models.Meals;
    app.route("/meals")
        .all(app.auth.authenticate())
        /**
         * @api {get} /meals GET the user's meals
         * @apiGroup Meals
         * @apiHeader {String} Authorization Token of authenticated user
         * @apiHeaderExample {json} Header
         *  {"Authorization": "JWT qweasdzxciopjklbnm"}
         * @apiSuccess {Number} meals.id Meal's Database ID
         * @apiSuccess {String} meals.mealType Meal Type (Breakfast, Lunch, Dinner, Snack)
         * @apiSuccess {String} meals.food Food type (ex. Chicken & Rice)
         * @apiSuccess {Number} meals.protein grams of protein in the meal
         * @apiSuccess {Number} meals.carbs grams of carbs in the meal
         * @apiSuccess {Number} meals.sugars grams of sugars in the meal
         * @apiSuccess {Number} meals.cals Amount of calories in the meal
         * @apiSuccess {Date} updatedAt Info Updated date
         * @apiSuccess {Date} createdAt Registered date
         * @apiSuccessExample {json} Success
         *  HTTP/1.1 200 OK
         *  [{
         *      "id": 1,
         *      "mealType": "Breakfast",
         *      "food": "Eggs",
         *      "protein": 12,
         *      "carbs": 1.1,
         *      "sugars": 1.1,
         *      "cals": 155,
         *      "updatedAt": "2024-04-24T15:20:11",
         *      "createdAt": "2024-04-24T15:20:11"
         *  },
         *  {...}]
         * @apiErrorExample {json} Meal Submission Error
         *  HTTP/1.1 412 Precondition Failed
         */
        .get((req, res) => {
            mealsData.findAll({
                where: {user_id: req.user.id}
            })
                .then(result => res.json(result))
                .catch(error => {
                    res.status(412).json({msg: error.message});
                });
        })
        /**
         * @api {post} /meals POST add a meal
         * @apiGroup Meals
         * @apiHeader {String} Authorization Token of authenticated user
         * @apiHeaderExample {json} Header
         *  {"Authorization": "JWT qweasdzxciopjklbnm"}
         * @apiParam {Object[]} meals Meal List
         * @apiParam {String} meals.mealType Meal Type (Breakfast, Lunch, Dinner, Snack)
         * @apiParam {String} meals.food Food type (ex. Chicken & Rice)
         * @apiParam {Number} meals.protein grams of protein in the meal
         * @apiParam {Number} meals.carbs grams of carbs in the meal
         * @apiParam {Number} meals.sugars grams of sugars in the meal
         * @apiParam {Number} meals.cals Amount of calories in the meal
         * @apiParamExample {json} input
         *  {
         *      "mealType": "Breakfast",
         *      "food": "Eggs",
         *      "protein": 12,
         *      "carbs": 1.1,
         *      "sugars": 1.1,
         *      "cals": 155
         *  }
         * @apiSuccess {Number} meals.id Meal's Database ID
         * @apiSuccess {String} meals.mealType Meal Type (Breakfast, Lunch, Dinner, Snack)
         * @apiSuccess {String} meals.food Food type (ex. Chicken & Rice)
         * @apiSuccess {Number} meals.protein grams of protein in the meal
         * @apiSuccess {Number} meals.carbs grams of carbs in the meal
         * @apiSuccess {Number} meals.sugars grams of sugars in the meal
         * @apiSuccess {Number} meals.cals Amount of calories in the meal
         * @apiSuccess {Date} updatedAt Info Updated date
         * @apiSuccess {Date} createdAt Registered date
         * @apiSuccess {Number} UserId Id of User that created the meal
         * @apiSuccessExample {json} Success
         *  HTTP/1.1 200 OK
         *  {
         *      "id": 1,
         *      "mealType": "Breakfast",
         *      "food": "Eggs",
         *      "protein": 12,
         *      "carbs": 1.1,
         *      "sugars": 1.1,
         *      "cals": 155,
         *      "updatedAt": "2024-04-24T15:20:11",
         *      "createdAt": "2024-04-24T15:20:11",
         *      "UserId": 1
         *  }
         * @apiErrorExample {json} Meal Submission Error
         *  HTTP/1.1 412 Precondition Failed
         */
        .post((req, res) => {
            req.body.UserId = req.user.id;
            mealsData.create(req.body)
                .then(result => res.json(result))
                .catch(error => {
                    res.status(412).json({msg:error.message});
                });
        });

    app.route("/meals/:id")
        .all(app.auth.authenticate())
        /**
         * @api {get} /meals/:id GET:ID a meal based off of ID
         * @apiGroup Meals
         * @apiHeader {String} Authorization Token of authenticated user
         * @apiHeaderExample {json} Header
         *  {"Authorization": "JWT qweasdzxciopjklbnm"}
         * @apiParam {id} id Meal id
         * @apiSuccess {Number} meals.id Meal's Database ID
         * @apiSuccess {String} meals.mealType Meal Type (Breakfast, Lunch, Dinner, Snack)
         * @apiSuccess {String} meals.food Food type (ex. Chicken & Rice)
         * @apiSuccess {Number} meals.protein grams of protein in the meal
         * @apiSuccess {Number} meals.carbs grams of carbs in the meal
         * @apiSuccess {Number} meals.sugars grams of sugars in the meal
         * @apiSuccess {Number} meals.cals Amount of calories in the meal
         * @apiSuccess {Date} updatedAt Info Updated date
         * @apiSuccess {Date} createdAt Registered date
         * @apiSuccessExample {json} Success
         *  HTTP/1.1 200 OK
         *  {
         *      "id": 1,
         *      "mealType": "Breakfast",
         *      "food": "Eggs",
         *      "protein": 12,
         *      "carbs": 1.1,
         *      "sugars": 1.1,
         *      "cals": 155,
         *      "updatedAt": "2024-04-24T15:20:11",
         *      "createdAt": "2024-04-24T15:20:11"
         *  }
         * @apiErrorExample {json} Meal Submission Error
         *  HTTP/1.1 412 Precondition Failed
         */
        .get((req, res) => {
            mealsData.findOne({where: req.params})
            .then(result => {
                if(result) {
                    res.json(result)
                } else {
                    res.sendStatus(404);
                }
            })
            .catch(error => {
                res.status(412).json({msg: error.message});
            });
        })
        /**
         * @api {put} /meals/:id UPDATE a Meal based off of ID
         * @apiGroup Meals
         * @apiHeader {json} Header
         *  {"Authorization": "JWT qweasdzxciopjklbnm"}
         * @apiParam {Number} meals.id Meal's database ID
         * @apiParam {String} meals.mealType Updated meal type
         * @apiParam {String} meals.food Updated meal food
         * @apiParam {Number} meals.protein Updated meal protein
         * @apiParam {Number} meals.carbs Updated meal carbs
         * @apiParam {Number} meals.sugars Updated meal sugars
         * @apiParam {Number} meals.cals Updated meal calories
         * @apiParamExample {json} Input
         *  {
         *      "id": 1,
         *      "mealType": "Breakfast",
         *      "food": "2 Eggs & 1 Bacon Strip",
         *      "protein": 20,
         *      "carbs": 2,
         *      "sugars": 1.1,
         *      "cals": 310
         *  }
         * @apiSuccessExample {json} Success
         *  HTTP/1.1 No Content
         * @apiErrorExample {json} Update Error
         *  HTTP/1.1 412 Precondition Failed
         */
        .put((req, res) => {
            mealsData.update(req.body, {where: {
                id: req.params.id,
                user_id: req.user.id
                }})
                .then(result => res.sendStatus(204))
                .catch(error => {
                    res.status(412).json({msg: error.message});
                });
        })
        /**
         * @api {delete} /meals/:id DELETE a meal 
         * @apiGroup Meals
         * @apiHeader {String} Authorization Token of authenticated user
         * @apiHeaderExample {json} Header
         *  {"Authorization": "JWT qweasdzxciopjklbnm"}
         * @apiParam {Number} id Meal id
         * @apiSuccessExample {json} Success
         *  HTTP/1.1 204 No content
         * @apiErrorExample {json} delete error
         *  HTTP/1.1 412 Precondition Failed
         */
        .delete((req, res) => {
            mealsData.destroy({where: req.params})
                .then(result => res.sendStatus(204))
                .catch(error => {
                    res.status(412).json({msg: error.message});
                });
        });
        
};