const dayjs = require("dayjs");

console.log("The wise elephant:");

console.log("\n");

console.log("┈┈┈╭━━━━┳━━━━━╮┈\n┏━╮┃╲▊┃╲╰╮╲╲╲╲┃┈\n┗╮┃┃╲╲┃╲╲┃╲╲╲╲┣╮\n┈┃╰╯┃╲╰━━╯╲╲╲╲┃┃\n┈╰━┳╯┳┓╲┏━┳━┓╲┃╰\n┈┈┈┃╲┃┃╲┃┈┃╲┃╲┃┈\n┈┈┈┗┻┛┗┻┛┈┗┻┻┻┛┈\n            ")


let day = dayjs().format('MM-DD-YYYY') // display date
let time = dayjs().format('HH:mm')

console.log("Date: " + day);
console.log("Time: " + time);