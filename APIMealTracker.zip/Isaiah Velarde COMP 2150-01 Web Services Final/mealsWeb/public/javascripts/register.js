let registerFrm = document.getElementById("registerFrm");
let registerBtn = document.getElementById("registerBtn");

registerFrm.registerBtn.onclick = function() {
    console.log("Register Button OnClick Functioning.");
    console.log(registerFrm.nameTxt.value);
    console.log(registerFrm.emailTxt.value);
    console.log(registerFrm.passwordPwd.value);
    fetch("http://localhost:3000/users",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        name: registerFrm.nameTxt.value,
        password: registerFrm.passwordPwd.value,
        email: registerFrm.emailTxt.value
      })
    })
    .then((response) => response.json())
    .then((data) => {
      console.log(data);
      regisSuccess();
    })
  }