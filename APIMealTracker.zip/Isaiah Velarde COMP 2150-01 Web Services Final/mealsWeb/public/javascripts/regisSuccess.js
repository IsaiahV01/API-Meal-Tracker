function regisSuccess () {
    document.querySelector(".regisPopup").classList.remove("active");
    document.querySelector(".loginPopup").classList.add("active");
}