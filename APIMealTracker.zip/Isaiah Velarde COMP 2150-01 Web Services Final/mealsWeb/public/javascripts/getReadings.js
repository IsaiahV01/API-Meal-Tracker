let token;

function getReadings() {
    fetch ("http://localhost:3000/meals",
  {
    method: "GET",
    headers: {
      "Authorization": "JWT " + token
    }
  })
  .then((response) => response.json())
  .then((data) => {
    console.log(data);
        let mealsTbl = document.getElementById("mealsTbl");
        let meals = "";
        let today = new Date();
        let calories = 0;
        let proteinCount = 0;
        let carbsCount = 0;
        let sugarsCount = 0;

        data.reverse().forEach(e => {
            let formattedDate = new Date(e.date).toLocaleDateString();

            meals += `
                <div class="cardContainer">
                    <div class="card">
                        <h1 class="mealCardType">${e.mealType}</h1>
                        <div class="cardContent">
                            <h3>${e.food}</h3>
                            <p>
                                ${e.protein} g Protein <br>
                                ${e.carbs} g Carbs <br>
                                ${e.sugars} g Sugars <br>
                                ${e.cals} Calories <br>
                            </p>
                            <p class="cardDate">${formattedDate}</p>
                            <button type="button" id="deleteMeal" name="deleteMealBtn" value="${e.id}" onclick="deleteMeal(${e.id})">Delete Meal</button>
                        </div>
                    </div>
                </div>
            `;
           

            if (isSameDay(new Date(e.date), today)) {
                calories += parseInt(e.cals);
                proteinCount += parseInt(e.protein);
                carbsCount += parseInt(e.carbs);
                sugarsCount += parseInt(e.sugars);
            }
        });

        document.getElementById("nutritionCal").innerText = calories;
        document.getElementById("nutritionProtein").innerText = `${proteinCount}g Protein`;
        document.getElementById("nutritionCarbs").innerText = `${carbsCount}g Carbs`;
        document.getElementById("nutritionSugars").innerText = `${sugarsCount}g Sugars`;

        mealsTbl.innerHTML = meals;
    });
}

function isSameDay(date1, date2) {
  return date1.getFullYear() === date2.getFullYear() &&
    date1.getMonth() === date2.getMonth() &&
    date1.getDate() === date2.getDate();
}

