function loggedIn() {
    
//variables
const scrollTo = document.getElementById("cloak");

    //cloaks login window & header buttons
    document.querySelector(".loginPopup").classList.remove("active");
    document.querySelector("#showcase .loginBtn").classList.add("cloakBtn");
    document.querySelector("#showcase .regisBtn").classList.add("cloakBtn");

    //reveals rest of page
    document.querySelector("#cloak").style.display = "block";
    //scrolls to bottom of header
    scrollTo.scrollIntoView({ behavior: "smooth", block: "start", inline: "nearest" });

}