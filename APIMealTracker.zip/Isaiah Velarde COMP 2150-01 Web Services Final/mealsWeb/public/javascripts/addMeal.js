let mealFrm = document.getElementById("mealFrm");


mealFrm.addMealBtn.onclick = function() {
    console.log("Add Meal Button OnClick Functioning.");
    let selectedMealType = mealFrm.mealTypeSelector.value;
    if(token != null) {
      console.log("You are logged in");
      //---------
      //All of this was because my database would put the date entry 1 day behind what I needed it to be (took me ~2.5 hours of googling)
      const selectedDate = new Date(mealFrm.entryDate.value);
      selectedDate.setHours(selectedDate.getHours() + 1);
      const utcDate = selectedDate.toISOString();
      //---------
      fetch("http://localhost:3000/meals",
    {
      method: "POST",
      headers: {
        "Content-Type" : "application/json",
        "Authorization": "JWT " + token
      },
      body: JSON.stringify({
        "mealType": selectedMealType,
        "food": mealFrm.foodTxt.value,
        "protein": mealFrm.proteinNum.value,
        "carbs": mealFrm.carbsNum.value,
        "sugars": mealFrm.sugarsNum.value,
        "cals": mealFrm.calsNum.value,
        "date": utcDate
      })
    })
    .then((response) => response.json())
    .then((data) => {
      console.log(data);
      getReadings();
      mealAdded();
    });
    } else {
      console.log("Login First");
    }
  }