
function deleteMeal(id) {
    fetch(`http://localhost:3000/meals/${id}`, {
            method: "DELETE",
            headers: {
                "Authorization": "JWT " + token
            }
        })
        .then(response => {
            if (response.ok) {
                console.log("Delete Success");
                getReadings();
            } else {
                alert("Delete failed");
            }
        })
        .catch(error => {
            console.error("Error deleting meal:", error);
            alert("Delete failed");
        });
}

