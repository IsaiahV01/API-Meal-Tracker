function mealAdded() {

    const scrollTo = document.getElementById("meals");


        document.querySelector(".mealPopup").classList.remove("active");
        scrollTo.scrollIntoView({ behavior: "smooth", block: "start", inline: "nearest" });


}