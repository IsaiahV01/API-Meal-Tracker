//Login Form Cloak
document.querySelector("#showLogin").addEventListener("click", function() {
    document.querySelector(".loginPopup").classList.add("active");
});

document.querySelector(".loginPopup .loginCloseBtn").addEventListener("click", function() {
    document.querySelector(".loginPopup").classList.remove("active");
});

//Register Form Cloak

document.querySelector("#showRegis").addEventListener("click", function() {
    document.querySelector(".regisPopup").classList.add("active");
});

document.querySelector(".regisPopup .regisCloseBtn").addEventListener("click", function() {
    document.querySelector(".regisPopup").classList.remove("active");
});

//Add Meal Form Cloak

document.querySelector("#showMeal").addEventListener("click", function() {
    document.querySelector(".mealPopup").classList.add("active");
});

document.querySelector(".mealPopup .mealCloseBtn").addEventListener("click", function() {
    document.querySelector(".mealPopup").classList.remove("active");
});