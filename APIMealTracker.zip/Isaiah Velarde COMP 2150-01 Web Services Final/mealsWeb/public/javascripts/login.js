let loginFrm = document.getElementById("loginFrm");

loginFrm.loginBtn.onclick = function() {
    console.log("Login Button OnClick Functioning.");
    fetch("http://localhost:3000/token",
  {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      email: loginFrm.emailTxt.value,
      password: loginFrm.passwordPwd.value
    })
  })
  .then((response) => response.json())
  .then((data) => {
    console.log(data);
    token = data.token;
    getReadings();
    loggedIn();
  });
  }